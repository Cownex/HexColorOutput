
## Installation

Install Hex-Color-Output via pip

```bash
  pip install -i https://test.pypi.org/simple/ hex-color-output==0.0.2
```

## Using
